function showSignup() {
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("signupForm").style.display = "block";
}

function showLogin() {
    document.getElementById("signupForm").style.display = "none";
    document.getElementById("loginForm").style.display = "block";
}

function handleSignup() {
    var username = document.getElementById("signupUsername").value;
    var phone = document.getElementById("signupPhone").value;
    var password = document.getElementById("signupPassword").value;

    if (username && phone && password) {
        localStorage.setItem("Email", username);
        localStorage.setItem("Password", password);
        localStorage.setItem("Phone Number", phone);
        Swal.fire({
            title: "Account Created!",
            text: "Your account has been created successfully.",
            icon: "success",
            backdrop: true,
            willClose: function() {
                showLogin();  
            }
        });
    } else {
        Swal.fire({
            title: "Error",
            text: "Please fill all fields!",
            icon: "error"
        });
    }
}

function handleLogin() {
    var username = document.getElementById("loginUsername").value;
    var password = document.getElementById("loginPassword").value;

    var storedPassword = localStorage.getItem("Password");
    var storedUsername = localStorage.getItem("Email");

    if (storedUsername === username && storedPassword === password) {
        Swal.fire({
            title: "Login Successful!",
            text: "Welcome back!",
            icon: "success",
            backdrop: true
        }).then(function() {
            window.location.href = "dashboard.html"; 
        });
    } else {
        Swal.fire({
            title: "Error",
            text: "Invalid username or password.",
            icon: "error"
        });
    }
}

  function startQuiz(topic) {
    localStorage.setItem("currentQuiz", topic);
    location.href = "quiz.html";
  }
  

  var quizzes = {
    html: [
        { question: "Q1-) What does HTML stand for?", options: ["Hyper Text Markup Language", "Home Tool Markup Language", "Hyperlinks and Text Markup Language"], answer: 0 },
        { question: "Q2-) Which tag is used to define a hyperlink?", options: ["<a>", "<link>", "<href>"], answer: 0 },
        { question: "Q3-) What is the purpose of the <head> tag?", options: ["Contains metadata", "Displays content", "Adds footer content"], answer: 0 },
        { question: "Q4-) Which tag is used to display an image?", options: ["<img>", "<image>", "<pic>"], answer: 0 },
        { question: "Q5-) Which attribute specifies an image's alternative text?", options: ["alt", "src", "title"], answer: 0 },
        { question: "Q6-) What is the correct way to define a heading?", options: ["<h1>", "<heading>", "<head>"], answer: 0 },
        { question: "Q7-) Which tag is used to create an ordered list?", options: ["<ol>", "<ul>", "<list>"], answer: 0 },
        { question: "Q8-) What does the <title> tag define?", options: ["Page title", "Heading", "Footer"], answer: 0 },
        { question: "Q9-) What is the default file extension for HTML files?", options: [".html", ".htm", ".html5"], answer: 0 },
        { question: "Q10-) Which attribute is used to open a link in a new tab?", options: ["target='_blank'", "target='_new'", "window='_blank'"], answer: 0 }
    ],
    
    css: [
        { question: "Q1-) What does CSS stand for?", options: ["Cascading Style Sheets", "Creative Style Sheets", "Computer Style Sheets"], answer: 0 },
        { question: "Q2-) Which property is used to change the background color?", options: ["background-color", "bg-color", "color"], answer: 0 },
        { question: "Q3-) Which property controls the text size?", options: ["font-size", "text-size", "size"], answer: 0 },
        { question: "Q4-) How do you apply bold text in CSS?", options: ["font-weight: bold;", "font-style: bold;", "font-bold: true;"], answer: 0 },
        { question: "Q5-) Which property is used to align text?", options: ["text-align", "text-position", "align-text"], answer: 0 },
        { question: "Q6-) What is the correct syntax for an ID selector?", options: ["#id", ".id", "*id"], answer: 0 },
        { question: "Q7-) Which property is used to create space inside an element?", options: ["padding", "margin", "border"], answer: 0 },
        { question: "Q8-) What does the z-index property control?", options: ["Stacking order", "Zoom level", "Index number"], answer: 0 },
        { question: "Q9-) Which value makes a position fixed to the viewport?", options: ["fixed", "absolute", "relative"], answer: 0 },
        { question: "Q10-) What unit is used for scalable font sizes?", options: ["em", "px", "cm"], answer: 0 }
    ],
    
    js: [
        { question: "Q1-) What is JavaScript primarily used for?", options: ["Adding interactivity", "Structuring content", "Styling webpages"], answer: 0 },
        { question: "Q2-) How do you declare a variable in JavaScript?", options: ["let", "var", "Both"], answer: 2 },
        { question: "Q3-) What is the correct syntax to create a function?", options: ["function myFunc()", "create function myFunc()", "function:myFunc()"], answer: 0 },
        { question: "Q4-) How do you call a function named myFunc?", options: ["myFunc()", "call myFunc()", "run myFunc()"], answer: 0 },
        { question: "Q5-) Which symbol is used for single-line comments?", options: ["//", "/*", "#"], answer: 0 },
        { question: "Q6-) What is the output of '2' + 2 in JavaScript?", options: ["22", "4", "Error"], answer: 0 },
        { question: "Q7-) Which method is used to find the length of a string?", options: ["length", "size", "count"], answer: 0 },
        { question: "Q8-) Which keyword is used to define constants?", options: ["const", "let", "var"], answer: 0 },
        { question: "Q9-) What does the isNaN function check?", options: ["Not a Number", "Is a Number", "Null Value"], answer: 0 },
        { question: "Q10-) Which statement loops through properties of an object?", options: ["for-in", "for", "while"], answer: 0 }
    ]
};

var currentQuiz = [];
var currentQuestionIndex = 0;
var timer;
var timeLeft = 10;
var score = 0;

function startQuiz(skill) {
    document.querySelector(".dashboard-container").style.display = "none";
    document.querySelector(".quiz-container").style.display = "block";
    currentQuiz = quizzes[skill];
    document.getElementById("quiz-title").textContent = "Quiz: " + skill.toUpperCase();
    currentQuestionIndex = 0;
    score = 0;  
    loadQuestion();
}

function loadQuestion() {
    if (currentQuestionIndex >= currentQuiz.length) {
        var percentage = (score / currentQuiz.length) * 100;
        var tagline = (percentage >= 80) ? "Excellent!" :
                      (percentage >= 50) ? "Good job!" : "Keep trying!";
        Swal.fire({
            icon: 'success',
            title: 'Congratulations!',
            html: "<p>You have completed the quiz.</p>" +
                  "<p><strong>Total Score: " + score + "/" + currentQuiz.length + "</strong></p>" +
                  "<p><strong>Percentage: " + percentage + "%</strong></p>" +
                  "<p><strong>Tagline: " + tagline + "</strong></p>",
            showCancelButton: true,
            confirmButtonText: 'Start Again',
            cancelButtonText: 'End Quiz'

            
        }).then(function(result) {
            if (result.isConfirmed) {
                location.reload();  
            } else {
                window.location.href = 'index.html';  
            }
        });
        return;
    }

    var questionData = currentQuiz[currentQuestionIndex];
    document.getElementById("question").textContent = questionData.question;
    var optionsContainer = document.getElementById("options-container");
    optionsContainer.innerHTML = "";
    for (var i = 0; i < questionData.options.length; i++) {
        var optionDiv = document.createElement("div");
        optionDiv.textContent = questionData.options[i];
        optionDiv.onclick = function(index) {
            return function() {
                selectOption(index);
            };
        }(i);
        optionsContainer.appendChild(optionDiv);
    }
    resetTimer();
}

function selectOption(index) {
    if (index === currentQuiz[currentQuestionIndex].answer) {
        score++;  
    }
    var optionsDivs = document.querySelectorAll("#options-container div");
    for (var i = 0; i < optionsDivs.length; i++) {
        optionsDivs[i].classList.remove("selected");
    }
    optionsDivs[index].classList.add("selected");
}

function nextQuestion() {
    currentQuestionIndex++;
    loadQuestion();
}

function resetTimer() {
    clearInterval(timer);
    timeLeft = 10;
    document.getElementById("timer").textContent = "Time Left: " + timeLeft + "s";
    timer = setInterval(function() {
        timeLeft--;
        document.getElementById("timer").textContent = "Time Left: " + timeLeft + "s";
        if (timeLeft <= 0) {
            clearInterval(timer);
            nextQuestion();
        }
    }, 1000);
}
